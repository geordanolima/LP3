/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhoheroislp3;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

/**
 *
 * @author Geordano
 */
@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)

public class Atributos implements Serializable {

    @Id
    @GeneratedValue
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private int vida;
    private int ataque;
    private int defesa;
    private int iniciativa;
    private String nome;

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public int getDefesa() {
        return defesa;
    }

    public void setDefesa(int defesa) {
        this.defesa = defesa;
    }

    public int getIniciativa() {
        return iniciativa;
    }

    public void setIniciativa(int iniciativa) {
        this.iniciativa = iniciativa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

   public Personagem SomaPersonagemArma(Personagem p1, Arma a1){
       p1.setVida(((int)p1.getVida()+a1.getVida()));
       p1.setAtaque(((int)p1.getAtaque()+a1.getAtaque()));
       p1.setDefesa(((int)p1.getDefesa()+a1.getDefesa()));
       p1.setIniciativa(((int)p1.getIniciativa()+a1.getIniciativa()));
       return p1;
   }

}
